<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Routes principais
Route::get('/', 'App\Http\Controllers\StoreController@index')->name('store');
Route::get('/admin', 'App\Http\Controllers\AdminController@index')->middleware('auth')->name('dashboard');

// Routes para páginas de administração
// Route::resource('admin/category', 'App\Http\Controllers\CategoryController');
// Route::resource('admin/product', 'App\Http\Controllers\ProductController');
Route::resource('admin/book', 'App\Http\Controllers\BookController');
Route::resource('admin/author', 'App\Http\Controllers\AuthorController');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
