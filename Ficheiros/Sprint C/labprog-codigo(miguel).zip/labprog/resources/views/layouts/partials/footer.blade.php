<!-- resources/views/layouts/partials/footer.blade.php -->
    <!-- Footer Section -->
    <footer class="bg-warning text-white py-5">
        <div class="container text-center">
            <img src="logo.png" alt="Storytails Logo" class="mx-auto mb-4" style="height: 50px;">
            <div class="d-flex justify-content-center gap-4">
                <a href="#" class="text-white text-decoration-none">Books</a>
                <a href="#" class="text-white text-decoration-none">Pricing</a>
                <a href="#" class="text-white text-decoration-none">Support</a>
                <a href="#" class="text-white text-decoration-none">Login</a>
                <a href="#" class="text-white text-decoration-none">Terms</a>
            </div>
            <p class="mt-4">&copy; 2021 storytail.pt</p>
        </div>
    </footer>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
