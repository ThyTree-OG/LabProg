

<?php $__env->startSection('content'); ?>
<h1>New Book</h1>
<div class="mb-3 col-md-4">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</div>

<form name="book" method="POST" action="<?php echo e(route('book.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="mb-3 col-md-6">
            <label for="title" class="form-label">Title</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>

        <div class="mb-3 col-md-6">
            <label for="cover_url" class="form-label">Cover URL</label>
            <input type="text" class="form-control" name="cover_url" id="cover_url" required>
        </div>
    </div>

    <div class="row">
        <div class="mb-3 col-md-12">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" name="description" id="description" rows="3" required></textarea>
        </div>
    </div>

    <div class="row">
        <div class="mb-3 col-md-3">
            <label for="read_time" class="form-label">Read Time</label>
            <input type="number" class="form-control" name="read_time" id="read_time" required>
        </div>

        <div class="mb-3 col-md-3">
            <label for="age_group" class="form-label">Age Group</label>
            <input type="text" class="form-control" name="age_group" id="age_group" required>
        </div>

        <div class="mb-3 col-md-3">
            <label for="access_level" class="form-label">Access Level</label>
            <input type="text" class="form-control" name="access_level" id="access_level" required>
        </div>
    </div>

    <div class="row">
        <div class="mb-3 col-md-3">
            <label for="is_active" class="form-label">Status</label>
            <select class="form-select" name="is_active" id="is_active" required>
                <option selected>Select Status</option>
                <option value="1">Active</option>
                <option value="0">Inactive</option>
            </select>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pws\labprog\resources\views/book/create.blade.php ENDPATH**/ ?>