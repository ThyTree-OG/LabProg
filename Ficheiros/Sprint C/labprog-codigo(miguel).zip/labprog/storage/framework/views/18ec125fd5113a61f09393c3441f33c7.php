

<?php $__env->startSection('content'); ?>

<h1> Books </h1>

<table id="books" class="display" style="width:100%">
    <thead>
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Cover URL</th>
            <th>Read Time</th>
            <th>Rating Medio</th>
            <th>Age Group</th>
            <th>Is Active</th>
            <th>Access Level</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($book->title); ?></td>
            <td><?php echo e($book->description); ?></td>
            <td><?php echo e($book->cover_url); ?></td>
            <td><?php echo e($book->read_time); ?></td>
            <td><?php echo e($book->rating_medio); ?></td>
            <td><?php echo e($book->age_group); ?></td>
            <td><?php echo e($book->is_active); ?></td>
            <td><?php echo e($book->access_level); ?></td>
            <td><?php echo e($book->created_at); ?></td>
            <td><?php echo e($book->updated_at); ?></td>
            <td style="width: 20%;text-align:right;">
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        Options
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="<?php echo e(route('book.show', $book->id)); ?>">
                            <i class="far fa-eye"></i> View</a>
                        </li>
                        <li><a class="dropdown-item" href="<?php echo e(route('book.edit', $book->id)); ?>">
                            <i class="far fa-edit"></i> Edit</a>
                        </li>
                        <li>
                            <form class="dropdown-item" method="POST" action="<?php echo e(route('book.destroy', $book->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="bt-destroy" onclick="return confirm('Are you sure?')" type="submit"><i class="far fa-trash-alt"></i> Delete</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a class="btn btn-primary" href="<?php echo e(route('book.create')); ?>">Add New Book</a>
<script>
    $(document).ready(function() {
        $('#books').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pws\labprog\resources\views/book/index.blade.php ENDPATH**/ ?>