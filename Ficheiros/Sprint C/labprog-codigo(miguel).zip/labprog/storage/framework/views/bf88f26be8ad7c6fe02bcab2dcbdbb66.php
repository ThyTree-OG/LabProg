<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <!-- Hero Section -->
    <div class="text-center bg-warning text-dark py-5 rounded">
        <h1>Find a book</h1>
        <form class="d-flex justify-content-center mt-3">
            <input type="text" class="form-control w-50 me-2" placeholder="e.g. title, author..." />
            <button class="btn btn-dark">Search</button>
        </form>
    </div>

    <!-- Tabs Section -->
    <div class="d-flex justify-content-center mt-4">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="nav-link active text-dark" href="#">New Books</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="#">Our Picks</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="#">Most Popular</a>
            </li>
        </ul>
    </div>

    <!-- Book List Section -->
    <div class="mt-5">
        <h2 class="text-center text-warning">New Books</h2>
        <div class="row row-cols-1 row-cols-md-4 g-4 mt-4 justify-content-center">
            <!-- Example Book Card -->
            <div class="col">
                <div class="card shadow-sm h-100 border-0">
                    <div class="card-body text-center">
                        <img src="https://via.placeholder.com/150" class="card-img-top rounded mb-3" alt="Charlotte's Web">
                        <h5 class="card-title fw-bold text-dark">Charlotte's Web</h5>
                        <button class="btn btn-warning text-dark px-4">Read</button>
                    </div>
                </div>
            </div>

            <!-- Add more cards as necessary -->
        </div>
    </div>
</div>

<!-- Footer Section -->
<footer class="bg-warning text-dark py-4 mt-5">
    <div class="container text-center">
        <p class="mb-0">Storytails Logo</p>
        <div class="d-flex justify-content-center gap-4 mt-3">
            <a href="#" class="text-dark text-decoration-none">Books</a>
            <a href="#" class="text-dark text-decoration-none">Pricing</a>
            <a href="#" class="text-dark text-decoration-none">Support</a>
            <a href="#" class="text-dark text-decoration-none">Login</a>
            <a href="#" class="text-dark text-decoration-none">Terms</a>
        </div>
        <p class="mt-4">&copy; 2021 storytail.pt</p>
    </div>
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pws\labprog\resources\views/home.blade.php ENDPATH**/ ?>