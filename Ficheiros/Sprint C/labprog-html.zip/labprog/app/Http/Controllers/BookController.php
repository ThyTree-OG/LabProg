<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;

class BookController extends Controller
{
    //
    public function index()
    {
        $books = Book::all();
        return view('store.index', [
            'books' => $books
        ]);
    }



    public function show($id)
{
    $book = Book::findOrFail($id);

    return view('book.details', [
        'book' => $book,
    ]);
}

    public function viewPdf($id)
{
    $book = Book::findOrFail($id);

    // Ensure the book has a valid PDF path
    if (!$book->pdf_path || !file_exists(public_path($book->pdf_path))) {
        abort(404, 'PDF not found');
    }

    return view('book.pdf', [
        'pdfPath' => asset($book->pdf_path),
        'book' => $book,
    ]);
}

}
