

<?php $__env->startSection('content'); ?>
<h1>New Product</h1>
<div class="mb-3 col-md-4">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</div>

<form name="product" method="POST" action="<?php echo e(route('product.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="mb-3 col-md-4">
            <label for="product" class="form-label">Product</label>
            <input type="text" class="form-control" id="product" name="name" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-2">
            <label for="price" class="form-label">Price</label>
            <input type="text" class="form-control" name="price" id="price" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-2">
            <label for="vat" class="form-label">VAT</label>
            <input type="text" class="form-control" name="vat" id="vat" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-2">
            <label for="sala_price" class="form-label">Sale Price</label>
            <input type="text" class="form-control" name="sala_price" id="sala_price" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-2">
            <label for="sale" class="form-label">Sale</label>
            <select value="" class="form-select" name="sale" aria-label="Sale" required>
                <option selected>Select Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
        </div>
    </div>

    <div class="row">
        <div class="mb-3 col-md-2">
            <label for="barcode" class="form-label">Bar Code</label>
            <input type="number" class="form-control" name="barcode" id="barcode" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-10">
            <label for="description" class="form-label">Description</label>
            <input type="text" class="form-control" name="description" id="description" aria-describedby="product" required>
        </div>
    </div>

    <br>

    <div class="row">
        <div class="mb-3 col-md-3">
            <label for="weight" class="form-label">Weight</label>
            <input type="number" class="form-control" name="weight" id="weight" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-3">
            <label for="width" class="form-label">Width</label>
            <input type="number" class="form-control" name="width" id="width" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-3">
            <label for="height" class="form-label">Height</label>
            <input type="number" class="form-control" name="height" id="height" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-3">
            <label for="length" class="form-label">Length</label>
            <input type="number" class="form-control" name="length" id="length" aria-describedby="product" required>
        </div>
    </div>

    <div class="row">
        <div class="mb-3 col-md-4">
            <label for="sku" class="form-label">SKU</label>
            <input type="text" class="form-control" name="sku" id="sku" aria-describedby="product" required>
        </div>
        <div class="mb-3 col-md-4">
            <label for="stock" class="form-label">Stock</label>
            <input type="number" class="form-control" name="stock" id="stock" aria-describedby="product" required>
        </div>
    </div>

    <div class="row">
        <div class="mb-3 col-md-3">
            <label for="category_id" class="form-label">Category</label>
            <select class="form-select" name="category_id" id="category_id" aria-describedby="product" required>
            <option selected>Select Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 col-md-3">
            <label for="color_id" class="form-label">Color</label>
            <select class="form-select" name="color_id" id="color_id" aria-describedby="product" required>
            <option selected>Select Color</option>
                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 col-md-3">
            <label for="size_id" class="form-label">Size</label>
            <select class="form-select" name="size_id" id="size_id" aria-describedby="product" required>
            <option selected>Select Size</option>
                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($size->id); ?>"><?php echo e($size->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 col-md-3">
            <label for="brand_id" class="form-label">Brand</label>
            <select class="form-select" name="brand_id" id="brand_id" aria-describedby="product" required>
                <option selected>Select Brand</option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <!-- <div class="row">
        <div class="mb-3 col-md-3">
            <label for="category_id" class="form-label">Category ID</label>
            <input type="text" class="form-control" name="category_id" id="category_id" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-3">
            <label for="color_id" class="form-label">Color ID</label>
            <input type="text" class="form-control" name="color_id" id="color_id" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-3">
            <label for="size_id" class="form-label">Size ID</label>
            <input type="text" class="form-control" name="size_id" id="size_id" aria-describedby="product" required>
        </div>

        <div class="mb-3 col-md-3">
            <label for="brand_id" class="form-label">Brand ID</label>
            <input type="text" class="form-control" name="brand_id" id="brand_id" aria-describedby="product" required>
        </div>
    </div> -->

    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pws\shoplink\resources\views/product/create.blade.php ENDPATH**/ ?>