

<?php $__env->startSection('content'); ?>

<h1>Categories</h1>

<form name="category" method="" action="<?php echo e(route('category.index')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3 col-md-4">
        <label for="category" class="form-label">Category</label>
        <input type="text" class="form-control" id="category" name="name" aria-describedby="category" placeholder="<?php echo e($category->name); ?>" disabled>
    </div>
    <div class="mb-3 col-md-4">
    <select class="form-select" name="status" aria-label="Status" disabled>
        <option value="" selected>Select Status</option>
        <option value="active" <?php echo e($category->status == 'active' ? 'selected' : ''); ?>>Active</option>
        <option value="inactive" <?php echo e($category->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
    </select>
    </div>
    <a class="btn btn-primary" href="<?php echo e(route('category.index')); ?>">Voltar</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pws\shoplink\resources\views/category/show.blade.php ENDPATH**/ ?>