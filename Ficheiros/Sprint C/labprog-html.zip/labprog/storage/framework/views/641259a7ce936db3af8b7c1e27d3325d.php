

<?php $__env->startSection('title', 'Book Details - ' . $book->title); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row">
        <!-- Book Cover -->
        <div class="col-md-4">
            <img src="<?php echo e(asset($book->cover_image)); ?>" alt="<?php echo e($book->title); ?>" class="img-fluid rounded shadow-sm">
        </div>

        <!-- Book Details -->
        <div class="col-md-8">
            <h1><?php echo e($book->title); ?></h1>
            <h4 class="text-muted">by <?php echo e($book->author); ?></h4>
            <p class="mt-3"><strong>Description:</strong> <?php echo e($book->description); ?></p>
            <p><strong>Category:</strong> <?php echo e($book->category); ?></p>
            <p><strong>Published Date:</strong> <?php echo e($book->published_date); ?></p>
            <p><strong>Price:</strong> $<?php echo e($book->price); ?></p>

            <!-- Action Buttons -->
            <div class="mt-4">
                <!-- Read Button -->
                <a href="<?php echo e(route('book.pdf', $book->id)); ?>" class="btn btn-primary">
                    Read Book <i class="fas fa-book-open"></i>
                </a>

                <!-- Audiobook Button -->
                <?php if($book->audiobook_url): ?>
                <a href="<?php echo e($book->audiobook_url); ?>" class="btn btn-secondary" target="_blank">
                    Listen to Audiobook <i class="fas fa-headphones-alt"></i>
                </a>
                <?php else: ?>
                <button class="btn btn-secondary disabled" title="Audiobook not available">
                    Audiobook Unavailable <i class="fas fa-headphones-alt"></i>
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Activity Section -->
    <div class="mt-5">
        <h3>Activities</h3>
        <p>Engage with the book in new ways:</p>
        <ul>
            <li><a href="">Take a Quiz</a></li>
            <li><a href="">Join the Discussion</a></li>
            <li><a href="">Complete a Challenge</a></li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luisa\Desktop\labprog\resources\views/book/details.blade.php ENDPATH**/ ?>