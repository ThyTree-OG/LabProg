<!-- resources/views/layouts/partials/footer.blade.php -->
    <!-- Footer Section -->
    <footer class="custom-footer text-white py-5">
        <div class="container text-center">
        <img src="<?php echo e(asset('assets/img/storytail-logo-06.png')); ?>" alt="Storytail Logo" style="width: 55px; height: auto;">
            <div class="d-flex justify-content-center gap-4">
                <a href="#" class="text-white text-decoration-none">Books</a>
                <a href="<?php echo e(route('pricing')); ?>" class="text-white text-decoration-none">Pricing</a>
                <a href="<?php echo e(route('contact')); ?>" class="text-white text-decoration-none">Contacts</a>
                <a href="<?php echo e(route('login')); ?>" class="text-white text-decoration-none">Login</a>
                <a href="<?php echo e(route('terms')); ?>" class="text-white text-decoration-none">Terms</a>
                <a href="<?php echo e(route('about')); ?>" class="text-white text-decoration-none">About</a>
            </div>
            <p class="mt-4">&copy; 2021 storytail.pt</p>
        </div>
    </footer>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\luisa\Desktop\labprog\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>