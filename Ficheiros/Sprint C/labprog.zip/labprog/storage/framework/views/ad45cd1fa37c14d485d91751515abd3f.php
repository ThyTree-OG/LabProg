

<?php $__env->startSection('content'); ?>

<h1> Products </h1>

<table id="product" class="display" style="width:100%">
    <thead>
        <tr>
            <th>Name</th>
            <th>Sku</th>
            <th>Description</th>
            <th>Barcode</th>
            <th>Category ID</th>
            <th>Price</th>
            <th>Sale Price</th>
            <th>Sale</th>
            <th>Stock</th>
            <th>Weight</th>
            <th>Color ID</th>
            <th>Size ID</th>
            <th>Width</th>
            <th>Height</th>
            <th>Length</th>
            <th>VAT</th>
            <th>Brand ID</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->sku); ?></td>
            <td><?php echo e($product->description); ?></td>
            <td><?php echo e($product->barcode); ?></td>
            <td><?php echo e($product->category_id); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td><?php echo e($product->sala_price); ?></td>
            <td><?php echo e($product->sale); ?></td>
            <td><?php echo e($product->stock); ?></td>
            <td><?php echo e($product->weight); ?></td>
            <td><?php echo e($product->color_id); ?></td>
            <td><?php echo e($product->size_id); ?></td>
            <td><?php echo e($product->width); ?></td>
            <td><?php echo e($product->height); ?></td>
            <td><?php echo e($product->length); ?></td>
            <td><?php echo e($product->vat); ?></td>
            <td><?php echo e($product->brand_id); ?></td>
            <td><?php echo e($product->created_at); ?></td>
            <td><?php echo e($product->updated_at); ?></td>
            <td style="width: 20%;text-align:right;">
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        Options
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="<?php echo e(route('product.show', $product->id)); ?>">
                            <i class="far fa-eye"></i> View</a>
                        </li>
                        <li><a class="dropdown-item" href="<?php echo e(route('product.edit', $product->id)); ?>">
                        <i class="far fa-edit"></i> Edit</a>
                    </li>
                        <li>
                            <form class="dropdown-item" method="POST" action="<?php echo e(route('product.destroy', $product->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="bt-destroy" onclick="return confirm('Are you sure?')" type="submit"><i class="far fa-trash-alt"></i> Delete</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a class="btn btn-primary" href="<?php echo e(route('product.create')); ?>">Adicionar</a>
<script>
    $(document).ready(function() {
        $('#product').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pws\shoplink\resources\views/product/index.blade.php ENDPATH**/ ?>