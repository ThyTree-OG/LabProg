

<?php $__env->startSection('title', 'Home - Storytails'); ?>

<?php $__env->startSection('content'); ?>

<!-- Search Section with Background Image -->
<header style="background-image: url('<?php echo e(asset('assets/img/background.png')); ?>');">
    <div class="container mx-auto text-center py-16">
        <h1 class="text-4xl font-bold text-gray-800">Find a book</h1>
        <form action="" method="GET" class="d-flex justify-content-center">
            <!-- Search Input Box -->
            <input
                type="text"
                name="query"
                placeholder="e.g. title, author..."
                class="form-control w-50 py-2 rounded-start border-0"
                style="max-width: 500px;"
            >
            <!-- Search Button -->
            <button type="submit" class="btn btn-warning rounded-end">
                <i class="bi bi-search"></i> Search
            </button>
        </form>
    </div>
</header>

<!-- Navigation Tabs for the Home Page -->
<nav class="bg-white shadow-md mt-4">
    <div class="container mx-auto flex justify-around py-4">
        <a href="#" class="text-orange-500 font-semibold">New Books</a>
        <a href="#" class="text-gray-600 hover:text-orange-500">Our Picks</a>
        <a href="#" class="text-gray-600 hover:text-orange-500">Most Popular</a>
    </div>
</nav>

<!-- Main Content for the page -->
<main class="container my-5">
    <h2 class="text-warning mb-4">New Books</h2>
    <div class="row row-cols-1 row-cols-md-4 g-4">
        <!-- Book Card -->
        <div class="col">
            <div class="card h-100 shadow-sm">
                <img src="charlottes-web.jpg" alt="Charlotte's Web" class="card-img-top" style="height: 200px; object-fit: cover;">
                <div class="card-body text-center">
                    <h5 class="card-title">Charlotte's Web</h5>
                    <button class="btn btn-warning mt-3">READ</button>
                </div>
            </div>
        </div>
        <!-- Repeat similar cards for other books -->
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luisa\Desktop\Storytail\resources\views/store/index.blade.php ENDPATH**/ ?>