

<?php $__env->startSection('content'); ?>
<h1>New Category</h1>

<form name="category" method="POST" action="<?php echo e(route('category.update', $category->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-3 col-md-4">
        <label for="category" class="form-label">Category</label>
        <input type="text" class="form-control" id="category" name="name" aria-describedby="category" placeholder="<?php echo e($category->name); ?>">
    </div>
    <div class="mb-3 col-md-4">
        <select class="form-select" name="status" aria-label="Status">
            <option value="" selected>Select Status</option>
            <option value="active" <?php echo e($category->status == 'active' ? 'selected' : ''); ?>>Active</option>
            <option value="inactive" <?php echo e($category->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
        </select>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pws\shoplink\resources\views/category/edit.blade.php ENDPATH**/ ?>