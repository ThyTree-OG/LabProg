

<?php $__env->startSection('content'); ?>
<h1>New Category</h1>
<div class="mb-3 col-md-4">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<form name="category" method="POST" action="<?php echo e(route('category.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3 col-md-4">
        <label for="category" class="form-label">Category</label>
        <input type="text" class="form-control" id="category" name="name" aria-describedby="category" required>
    </div>
    <div class="mb-3 col-md-4">
    <select value="" class="form-select" name="status" aria-label="Status" required>
        <option selected>Select Status</option>
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
        </select>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pws\shoplink\resources\views/category/create.blade.php ENDPATH**/ ?>