<footer>
    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Storytail Logo" class="logo" style="height: 50px;">
    <div>
        <a href="#">Books</a>
        <a href="#">Pricing</a>
        <a href="#">Support</a>
        <a href="#">Login</a>
        <a href="#">Terms</a>
    </div>
    <p>&copy; 2021 storytail.pt</p>
</footer>
<?php /**PATH C:\Users\luisa\Desktop\shoplink\resources\views/partials/footer.blade.php ENDPATH**/ ?>