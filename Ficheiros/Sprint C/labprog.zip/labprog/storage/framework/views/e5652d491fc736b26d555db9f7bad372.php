

<?php $__env->startSection('content'); ?>
<h1>New Product</h1>

<div class="mb-3 col-md-4">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</div>

<form name="product" method="POST" action="<?php echo e(route('product.update', $product->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="mb-3 col-md-4">
            <label for="product" class="form-label">Product</label>
            <input type="text" class="form-control" id="product" name="name" aria-describedby="product" placeholder="<?php echo e($product->name); ?>">
        </div>

        <div class="mb-3 col-md-2">
            <label for="price" class="form-label">Price</label>
            <input type="text" class="form-control" name="price" id="price" aria-describedby="product" placeholder="<?php echo e($product->price); ?>">
        </div>

        <div class="mb-3 col-md-2">
            <label for="vat" class="form-label">VAT</label>
            <input type="text" class="form-control" name="vat" id="vat" aria-describedby="product" placeholder="<?php echo e($product->vat); ?>">
        </div>

        <div class="mb-3 col-md-2">
            <label for="sala_price" class="form-label">Sale Price</label>
            <input type="text" class="form-control" name="sala_price" id="sala_price" aria-describedby="product" placeholder="<?php echo e($product->sala_price); ?>">
        </div>

        <div class="mb-3 col-md-2">
            <label for="sale" class="form-label">Sale</label>
            <select class="form-select" name="sale" aria-label="Sale">
                <option>Select Status</option>
                <option value="active" <?php echo e($product->sale == "active" ? "selected" : ""); ?>>Active</option>
                <option value="inactive" <?php echo e($product->sale == "inactive" ? "" : "selected"); ?>>Inactive</option>
            </select>
        </div>
    </div>

    <div class="row">
        <div class="mb-3 col-md-2">
            <label for="barcode" class="form-label">Bar Code</label>
            <input type="text" class="form-control" name="barcode" id="barcode" aria-describedby="product" placeholder="<?php echo e($product->barcode); ?>">
        </div>

        <div class="mb-3 col-md-10">
            <label for="description" class="form-label">Description</label>
            <input type="text" class="form-control" name="description" id="description" aria-describedby="product" placeholder="<?php echo e($product->description); ?>">
        </div>
    </div>

    <br>

    <div class="row">
        <div class="mb-3 col-md-3">
            <label for="weight" class="form-label">Weight</label>
            <input type="text" class="form-control" name="weight" id="weight" aria-describedby="product" placeholder="<?php echo e($product->weight); ?>">
        </div>

        <div class="mb-3 col-md-3">
            <label for="width" class="form-label">Width</label>
            <input type="text" class="form-control" name="width" id="width" aria-describedby="product" placeholder="<?php echo e($product->width); ?>">
        </div>

        <div class="mb-3 col-md-3">
            <label for="height" class="form-label">Height</label>
            <input type="text" class="form-control" name="height" id="height" aria-describedby="product" placeholder="<?php echo e($product->height); ?>">
        </div>

        <div class="mb-3 col-md-3">
            <label for="length" class="form-label">Length</label>
            <input type="text" class="form-control" name="length" id="length" aria-describedby="product" placeholder="<?php echo e($product->length); ?>">
        </div>
    </div>

    <div class="row">
        <div class="mb-3 col-md-4">
            <label for="sku" class="form-label">SKU</label>
            <input type="text" class="form-control" name="sku" id="sku" aria-describedby="product" placeholder="<?php echo e($product->sku); ?>">
        </div>
        <div class="mb-3 col-md-4">
            <label for="stock" class="form-label">Stock</label>
            <input type="text" class="form-control" name="stock" id="stock" aria-describedby="product" placeholder="<?php echo e($product->stock); ?>">
        </div>
    </div>

    <div class="row">
        <div class="mb-3 col-md-3">
            <label for="category_id" class="form-label">Category (ID)</label>
            <select class="form-select" name="category_id" id="category_id" aria-describedby="product" required>
            <option selected>Select Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?> (<?php echo e($category->id); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 col-md-3">
            <label for="color_id" class="form-label">Color (ID)</label>
            <select class="form-select" name="color_id" id="color_id" aria-describedby="product" required>
            <option selected>Select Color</option>
                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?> (<?php echo e($color->id); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 col-md-3">
            <label for="size_id" class="form-label">Size (ID)</label>
            <select class="form-select" name="size_id" id="size_id" aria-describedby="product" required>
            <option selected>Select Size</option>
                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($size->id); ?>"><?php echo e($size->name); ?> (<?php echo e($size->id); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 col-md-3">
            <label for="brand_id" class="form-label">Brand (ID)</label>
            <select class="form-select" name="brand_id" id="brand_id" aria-describedby="product" required>
                <option selected>Select Brand</option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?> (<?php echo e($brand->id); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pws\shoplink\resources\views/product/edit.blade.php ENDPATH**/ ?>