<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Storytail'); ?></title>
    
    <!-- Link to Custom Storytail CSS -->
    <link href="<?php echo e(asset('css/storytail.css')); ?>" rel="stylesheet">
    
    <!-- Link to Google Fonts for Montserrat -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    
  
    
   
</head>
<?php /**PATH C:\Users\luisa\Desktop\shoplink\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>