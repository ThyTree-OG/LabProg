<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

    <!-- Main Content Section -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer Section -->
    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>

<?php /**PATH C:\Users\luisa\Desktop\Storytail\resources\views/layouts/app.blade.php ENDPATH**/ ?>