@extends('layouts.admin')

@section('content')
<h1>Show Product</h1>

<div class="mb-3 col-md-4">
    <div class="row">
        <label for="product_id" class="form-label">Product ID</label>
        <input type="text" class="form-control" id="product_id" value="{{ $product->id }}" readonly>

        <label for="product_name" class="form-label">Product Name</label>
        <input type="text" class="form-control" id="product_name" value="{{ $product->name }}" readonly>
        
        <label for="sku" class="form-label">SKU</label>
        <input type="text" class="form-control" id="sku" value="{{ $product->sku }}" readonly>
        
        <label for="barcode" class="form-label">Barcode</label>
        <input type="text" class="form-control" id="barcode" value="{{ $product->barcode }}" readonly>
        
        <label for="price" class="form-label">Price</label>
        <input type="text" class="form-control" id="price" value="{{ $product->price }}" readonly>
        
        <label for="sale_price" class="form-label">Sale Price</label>
        <input type="text" class="form-control" id="sale_price" value="{{ $product->sale_price }}" readonly>
        
        <label for="stock" class="form-label">Stock</label>
    </div>
    <div class="row">
        <input type="text" class="form-control" id="stock" value="{{ $product->stock }}" readonly>
        
        <label for="weight" class="form-label">Weight</label>
        <input type="text" class="form-control" id="weight" value="{{ $product->weight }}" readonly>
        
        <label for="width" class="form-label">Width</label>
        <input type="text" class="form-control" id="width" value="{{ $product->width }}" readonly>
        
        <label for="height" class="form-label">Height</label>
    </div>
    <div class="row">
        <input type="text" class="form-control" id="height" value="{{ $product->height }}" readonly>
        
        <label for="length" class="form-label">Length</label>
        <input type="text" class="form-control" id="length" value="{{ $product->lenght }}" readonly>
        
        <label for="vat" class="form-label">VAT</label>
        <input type="text" class="form-control" id="vat" value="{{ $product->vat }}" readonly>
        
        <label for="sale" class="form-label">Sale</label>
    </div>
    <div class="row">
        <input type="text" class="form-control" id="sale" value="{{ $product->sale ? 'True' : 'False' }}" readonly>
        
        <label for="category_id" class="form-label">Category</label>
        <input type="text" class="form-control" id="category_id" value="{{ $product->category_id}}" readonly>
    </div>
    <div class="row">
        <label for="brand_id" class="form-label">Brand</label>
        <input type="text" class="form-control" id="brand_id" value="{{ $product->brand_id }}" readonly>
        
        <label for="color_id" class="form-label">Color</label>
        <input type="text" class="form-control" id="color_id" value="{{ $product->color_id  }}" readonly>
        
        <label for="size_id" class="form-label">Size</label>
        <input type="text" class="form-control" id="size_id" value="{{ $product->size_id }}" readonly>
        
        <label for="description" class="form-label">Description</label>
        <input type="text" class="form-control" id="description" value="{{ $product->description }}" readonly>
    </div>
    
    <div class="mb-3 col-md-4">
      <!-- You can add any additional elements here -->
    </div>
    
    <a class="btn btn-primary" href="{{ route('products.index') }}">Back to Products</a>
</div>
@endsection
