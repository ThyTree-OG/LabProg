@extends('layouts.admin')

@section('content')
    <h1>Products</h1>

    

    <table id="products" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>sku</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>description</th>
                <th>sale</th>
                <th>sale_price</th>
                <th>barcode</th>
                <th>weight</th>
                <th>width</th>
                <th>length</th>
                <th>vat</th>
                <th>category_id</th>
                <th>color_id</th>
                <th>size_id</th>
                <th>brand_id</th>
            </tr>
        </thead>
        <tbody>
            @foreach($products as $product)
                <tr>
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->price }}</td>
                    <td>{{ $product->stock }}</td>
                    <td>{{ $product->sku }}</td>
                    <td>{{ $product->created_at }}</td>
                    <td>{{ $product->updated_at }}</td>
                    <td>{{ $product->description}}</td>
                    <td>{{ $product->sale}}</td>
                    <td>{{ $product->sale_price}}</td>
                    <td>{{ $product->barcode}}</td>
                    <td>{{ $product->weight}}</td>
                    <td>{{ $product->width}}</td>
                    <td>{{ $product->lenght }}</td>
                    <td>{{ $product->category_id }}</td>
                    <td>{{ $product->color_id }}</td>
                    <td>{{ $product->size_id}}</td>
                    <td>{{ $product->brand_id }}</td>
                    <td style="width: 20%;text-align:right;">
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton1"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                Options
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                <li>
                                    <a class="dropdown-item" href="{{ route('products.show', $product->id) }}">
                                        <i class="far fa-eye"></i> View
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="{{ route('products.edit', $product->id) }}">
                                        <i class="far fa-edit"></i> Edit
                                    </a>
                                </li>
                                <li>
                                    <form class="dropdown-item"
                                          action="{{ route('products.destroy', $product->id) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button class="bt-destroy"
                                                onclick="return confirm('Are you sure you want to delete this product?')"
                                                type="submit">
                                            <i class="far fa-trash-alt"></i> Delete
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <a class="btn btn-primary" href="{{ route('products.create') }}">Add Product</a>
    <script>
        $(document).ready(function () {
            $('#products').DataTable();
        });
    </script>
@endsection