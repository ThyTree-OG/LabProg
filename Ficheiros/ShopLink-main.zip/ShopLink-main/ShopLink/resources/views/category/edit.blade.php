@extends('layouts.admin')
  
  @section('content')
  <h1>Edit Category</h1>
  <div class="mb-3 col-md-4">
    @if($errors->any())
      <div class="alert alert-danger">
        <ul>
          @foreach($errors->all() as $error)
            <li>{{$error}}</li>
          @endforeach
        </ul>
      </div>
    @endif
  </div>
  <form name="category" method="POST" action="{{ route('category.update', $category->id) }}">
      @csrf
      @method('PUT')
      <div class="mb-3 col-md-4">
        <label for="category" class="form-label">Category</label>
        <input type="text" class="form-control" id="category" name="name"  value="{{$category->name}}" aria-describedby="category" required>
      </div>
      <div class="mb-3 col-md-4">
      <select class="form-select" name="status" aria-label="Status" required>
          <option value="" selected>Select Status</option>
          <option value="active" {{$category->status == 'active' ? 'selected' : ''}} >Active</option>
          <option value="inactive" {{$category->status == 'inactive' ? 'selected' : ''}} >Inactive</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  @endsection
  