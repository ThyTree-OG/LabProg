@extends('layouts.admin')
  
  @section('content')
  <h1>Show Category</h1>
  
  <form name="category" method="POST" action="{{ route('category.store') }}">
      @csrf
      <div class="mb-3 col-md-4">
        <label for="category" class="form-label">Category</label>
        <input type="text" class="form-control" id="category"  name="name" value="{{$category->name}}" aria-describedby="category" disabled>
      </div>
      <div class="mb-3 col-md-4">
      <select class="form-select" name="status" aria-label="Status" disabled>
          <option value="" selected>Select Status</option>
          <option value="active" {{$category->status == 'active' ? 'selected' : ''}} >Active</option>
          <option value="inactive" {{$category->status == 'inactive' ? 'selected' : ''}} >Inactive</option>
        </select>
      </div>
    </form>
    <a class="btn btn-primary" href="{{route('category.index')}}">Voltar</a>
  @endsection
  