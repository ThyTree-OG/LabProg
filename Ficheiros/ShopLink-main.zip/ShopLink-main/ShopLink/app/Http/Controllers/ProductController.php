<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Size;
use App\Models\Color;
use Illuminate\Http\Request;


class ProductController extends Controller
{
    public function index()
    {
        $products = Product::all();
        
        return view('product.index',[
            'products'=>$products
        ]);
    }

    
    public function create()
    {
        $categories = Category::all();
        $brands = Brand::all();
        $sizes= Size::all();
        $colors=Color::all();
        return view('product.create',[
            'categories'=>$categories,
            'brands'=>$brands,
            'sizes'=>$sizes,
            'colors'=>$colors,
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required|max:255|min:3',
            'sku'=> 'required|max:20|min:3|unique:products',
            'barcode'=>'required|max:20|min:3|unique:products',
            'price'=>'required|numeric|min:0.01',
            'sale_price'=>'required|numeric|min:0.01',
            'sale'=>'required|boolean',
            'stock'=>'required|numeric|min:0',
            'weight'=>'required|numeric|min:0',
            'height'=>'required|numeric|min:0',
            'lenght'=>'required|numeric|min:0',
            'vat'=>'required|numeric|min:0'

        ]);

        $product = new Product();

        $product->name = $request->name;
        $product->sku = $request->sku;
        $product->description = $request->description;
        $product->barcode = $request->barcode;
        $product->category_id = $request->category_id;
        $product->price = $request->price;
        $product->sale_price = $request->sale_price;
        $product->sale = $request->sale;
        $product->stock = $request->stock;
        $product->weight = $request->weight;
        $product->color_id = $request->color_id;
        $product->size_id = $request->size_id;
        $product->width = $request->width;
        $product->lenght = $request->lenght;
        $product->height = $request->height;
        $product->vat = $request->vat;
        $product->brand_id= $request->brand_id; 


        $product->save();

        return redirect()-> route('products.index') ;
    }
    public function show(string $id)
{
    $product = Product::findOrFail($id);
    $categories = Category::all();
    $brands = Brand::all();
    $sizes = Size::all();
    $colors = Color::all();

    return view('products.show', [
        'product' => $product,
        'categories' => $categories,
        'brands' => $brands,
        'sizes' => $sizes,
        'colors' => $colors,
    ]);
}

public function edit(string $id)
{   
    $product = Product::find($id);
    $categories = Category::all();
    $brands = Brand::all();
    $sizes = Size::all();
    $colors = Color::all();
    
    return view('product.edit',[
        'product' => $product,
        'categories' => $categories,
        'brands' => $brands,
        'sizes' => $sizes,
        'colors' => $colors,
    ]);
}

public function update(Request $request, string $id)
{
    $request->validate([
            'name'=>'required|max:255|min:3',
            'sku'=> 'required|max:20|min:3|unique:products',
            'barcode'=>'required|max:20|min:3|unique:products',
            'price'=>'required|numeric|min:0.01',
            'sale_price'=>'required|numeric|min:0.01',
            'sale'=>'required|boolean',
            'stock'=>'required|numeric|min:0',
            'weight'=>'required|numeric|min:0',
            'height'=>'required|numeric|min:0',
            'lenght'=>'required|numeric|min:0',
            'vat'=>'required|numeric|min:0'
    ]);

    if(Product::where('id',$id)->exists()){
        $product= Product::find($id);

        $product->name = $request->name;
        $product->sku = $request->sku;
        $product->description = $request->description;
        $product->barcode = $request->barcode;
        $product->category_id = $request->category_id;
        $product->price = $request->price;
        $product->sale_price = $request->sale_price;
        $product->sale = $request->sale;
        $product->stock = $request->stock;
        $product->weight = $request->weight;
        $product->color_id = $request->color_id;
        $product->size_id = $request->size_id;
        $product->width = $request->width;
        $product->lenght = $request->lenght;
        $product->height = $request->height;
        $product->vat = $request->vat;
        $product->brand_id= $request->brand_id; 

        $product->save();
    }
    return redirect()->route('products.index');
}




    public function destroy(string $id)
    {
        if(Product::where('id',$id)->exists()){
            $product= Product::find($id);
            $product->delete();
        }
        return redirect()->route('products.index');
    }

}
