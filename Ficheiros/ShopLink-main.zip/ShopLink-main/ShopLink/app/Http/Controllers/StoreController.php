<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use League\Flysystem\UrlGeneration\PublicUrlGenerator;

class StoreController extends Controller
{
    Public function index()
    {
        return view('store.index' , [

        ]);

    }
}
